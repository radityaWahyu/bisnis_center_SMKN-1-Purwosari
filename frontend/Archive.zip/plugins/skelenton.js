import Vue from "vue";
import Skelenton from "vue-loading-skeleton";

Vue.use(Skelenton);
