<template>
  <div class="footer">
    <div class="container">
      <p class="copyright">
        Created By : Tim IT SMK Negeri 1 Purwosari Pasuruan
      </p>
    </div>
  </div>
</template>
