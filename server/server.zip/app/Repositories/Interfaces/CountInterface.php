<?php

namespace App\Repositories\Interfaces;

interface CountInterface
{
  public function count(array $data);
}